# Imports

import os
import sys
import boto3
import shutil
import brotli
import urllib3
import tarfile
import subprocess

from tarfile import TarInfo

# Unpack
decompressed_data = brotli.decompress('/opt/lo.tar.br')
tar = tarfile.open(decompressed_data)
for TarInfo in tar:
  tar.extract(TarInfo.name, path='/tmp/')

# Download the TAR
# url = "https://s3.amazonaws.com/lambda-libreoffice-demo/lo.tar.br"
# c = urllib3.PoolManager()
# with c.request('GET', url, preload_content=False) as res, open('/tmp/lo.tar.br', 'wb') as out_file:
#   shutil.copyfileobj(res, out_file)

# Extract the TAR
# tar = tarfile.open('/tmp/lo.tar.br', "r:bz2")
# for TarInfo in tar:
#   tar.extract(TarInfo.name, path='/tmp/')

# Set some vars

s3_bucket = boto3.resource("s3").Bucket("leafsheets-django")
convertCommand = "/tmp/instdir/program/soffice.bin --headless --invisible --nodefault --nofirststartwizard --nolockcheck --nologo --norestore --convert-to pdf --outdir"

# Handler

def lambda_handler(event,context):
  inputFileName = event['filename']
  # Put object wants to be converted in s3
  with open(f'/tmp/{inputFileName}', 'wb') as data:
      s3_bucket.download_fileobj(f'static/fixtures/docs/{inputFileName}', data)

  # Execute libreoffice to convert input file
  os.system(f"cd /tmp && {convertCommand} {inputFileName}")

  # Save converted object in S3
  outputFileName, _ = os.path.splitext(inputFileName)
  outputFileName = outputFileName  + ".pdf"
  f = open(f'/tmp/{outputFileName}','rb')
  s3_bucket.put_object(Key=outputFileName,Body=f,ACL="public-read")
  f.close()